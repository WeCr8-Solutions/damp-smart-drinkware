
        // Mock Firebase and services
        window.require = () => ({});
        window.firebase = {
          initializeApp: () => ({}),
          auth: () => ({
            onAuthStateChanged: () => {},
            currentUser: null
          }),
          messaging: () => ({
            getToken: () => Promise.resolve(),
            onMessage: () => {}
          }),
          analytics: () => ({
            logEvent: () => {}
          })
        };
        // Mock Performance Monitor
        window.DAMPPerformanceMonitor = DAMPPerformanceMonitor;
      